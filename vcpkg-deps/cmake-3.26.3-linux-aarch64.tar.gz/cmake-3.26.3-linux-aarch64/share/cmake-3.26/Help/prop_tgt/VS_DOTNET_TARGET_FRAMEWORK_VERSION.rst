VS_DOTNET_TARGET_FRAMEWORK_VERSION
----------------------------------

Specify the .NET target framework version.

Used to specify the .NET target framework version for C++/CLI. For
example, "v4.5".

This property is deprecated and should not be used anymore. Use
:prop_tgt:`DOTNET_TARGET_FRAMEWORK` or
:prop_tgt:`DOTNET_TARGET_FRAMEWORK_VERSION` instead.
