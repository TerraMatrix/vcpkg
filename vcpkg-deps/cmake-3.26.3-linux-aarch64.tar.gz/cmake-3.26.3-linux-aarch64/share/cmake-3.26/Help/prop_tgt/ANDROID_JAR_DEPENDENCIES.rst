ANDROID_JAR_DEPENDENCIES
------------------------

.. versionadded:: 3.4

Set the Android property that specifies JAR dependencies.
This is a string value property. This property is initialized
by the value of the :variable:`CMAKE_ANDROID_JAR_DEPENDENCIES`
variable if it is set when a target is created.
