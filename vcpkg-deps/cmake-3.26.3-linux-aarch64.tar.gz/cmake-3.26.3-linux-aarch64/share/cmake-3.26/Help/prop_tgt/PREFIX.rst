PREFIX
------

What comes before the library name.

A target property that can be set to override the prefix (such as
``lib``) on a library name.
